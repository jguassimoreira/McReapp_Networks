from numpy import loadtxt
import os

lines = loadtxt("cluster_info_DAN.txt", comments="#", delimiter="\t", unpack=False)
labs = ["rLOC_A", "lPCG_A", "PCC_A", "lLOC_A", "rLOC_B", "rAI_A", "rPCG_A", "lLOC_B", "rPCG_B", "lLOC_C", "ACC_A",
        "lSPC_A", "mPFC_A", "lMFG_A", "lSPC_B", "rSPC_A", "rSPC_B", "lMFG_B", "rPCG_C", "rPCG_D", "lSPC_C", "lSPC_D",
        "lSPC_E", "lLOC_D", "lLOC_E", "mPFC_B", "mPFC_C"]

for ln in range(0,len(lines)):
    x = lines[ln][3]
    y = lines[ln][4]
    z = lines[ln][5]
    os.system('fslmaths cluster_index_dan.nii.gz -mul 0 -add 1 -roi %s 1 %s 1 %s 1 0 1 %spoint -odt float'%(x, y, z, labs[ln]))
    os.system('fslmaths %spoint.nii.gz -kernel sphere 4 -fmean %s_sphere -odt float'%(labs[ln], labs[ln]))
    print labs[ln]

os.system('rm *point*')

    
    
