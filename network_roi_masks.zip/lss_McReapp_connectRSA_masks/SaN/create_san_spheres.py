from numpy import loadtxt
import os

lines = loadtxt("cluster_info_SaN.txt", comments="#", delimiter="\t", unpack=False)
labs = ["rAI_A", "lAI_A", "lTPJ_A", "ACC_A", "ACC_B", "lAI_B", "PCC_A", "rAI_B", "rAI_C", "lAI_C", "PCC_B", "PCC_C",
        "lTPJ_B", "lTPJ_C"]

for ln in range(0,len(lines)):
    x = lines[ln][3]
    y = lines[ln][4]
    z = lines[ln][5]
    os.system('fslmaths cluster_index_san.nii.gz -mul 0 -add 1 -roi %s 1 %s 1 %s 1 0 1 %spoint -odt float'%(x, y, z, labs[ln]))
    os.system('fslmaths %spoint.nii.gz -kernel sphere 4 -fmean %s_sphere -odt float'%(labs[ln], labs[ln]))
    print labs[ln]

os.system('rm *point*')

    
    
