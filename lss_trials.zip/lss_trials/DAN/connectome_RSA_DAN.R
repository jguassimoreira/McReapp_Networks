library(psych)
library(igraph)
library(readxl)

subs = c(1001, 1002, 1005, 1006, 1007, 1008, 1031, 1032, 1034, 1036,
         1072, 1077, 1078, 1081, 1089, 1090, 1091, 1098, 1105, 1106,
         1111, 1115, 1116, 1117, 1118, 1119, 1125, 1126, 1127, 1128,
         1132, 1133, 1134, 1136, 1142, 1143, 1145, 1146, 1147, 1152,
         1153, 1154, 1157, 1166, 1167, 1173, 1176, 1185, 1195, 1207,
         1208, 1218, 1226, 1227, 1228, 1233, 1237, 1239, 1240, 1244,
         1245, 1246, 1248, 1249, 1250, 1252, 1253, 1256, 1262, 1263)


sdFarMat = as.data.frame(matrix(NaN, 70, 27))
names(sdFarMat) <- c('lLOC_A_sphere', 'lLOC_B_sphere', 'lLOC_C_sphere', 'lLOC_D_sphere', 'lLOC_E_sphere', 
                     'rLOC_A_sphere', 'rLOC_B_sphere',
                     'lSPC_A_sphere', 'lSPC_B_sphere', 'lSPC_C_sphere', 'lSPC_D_sphere', 'lSPC_E_sphere',
                     'rSPC_A_sphere', 'rSPC_B_sphere',
                     'lPCG_A_sphere',
                     'rPCG_A_sphere', 'rPCG_B_sphere', 'rPCG_C_sphere', 'rPCG_D_sphere', 
                     'ACC_A_sphere', 
                     'PCC_A_sphere',
                     'rAI_A_sphere', 
                     'lMFG_A_sphere', 'lMFG_B_sphere',
                     'mPFC_A_sphere', 'mPFC_B_sphere', 'mPFC_C_sphere')
sdLookMat = as.data.frame(matrix(NaN, 70, 27))
names(sdLookMat) <- c('lLOC_A_sphere', 'lLOC_B_sphere', 'lLOC_C_sphere', 'lLOC_D_sphere', 'lLOC_E_sphere', 
                      'rLOC_A_sphere', 'rLOC_B_sphere',
                      'lSPC_A_sphere', 'lSPC_B_sphere', 'lSPC_C_sphere', 'lSPC_D_sphere', 'lSPC_E_sphere',
                      'rSPC_A_sphere', 'rSPC_B_sphere',
                      'lPCG_A_sphere',
                      'rPCG_A_sphere', 'rPCG_B_sphere', 'rPCG_C_sphere', 'rPCG_D_sphere', 
                      'ACC_A_sphere', 
                      'PCC_A_sphere',
                      'rAI_A_sphere', 
                      'lMFG_A_sphere', 'lMFG_B_sphere',
                      'mPFC_A_sphere', 'mPFC_B_sphere', 'mPFC_C_sphere')

outSim = c(rep(NaN, 70))
modDiff = c(rep(NaN, 70))
commDiff = c(rep(NaN, 70))


for (i in 1:length(subs)) {
  
  far <- read.table(sprintf("C:/Users/jguas/Desktop/McReapp/lss_trials/DAN/%s_expanded_farNeg_lss_DAN_ts.txt", subs[i]))
  names(far) <- c('lLOC_A_sphere', 'lLOC_B_sphere', 'lLOC_C_sphere', 'lLOC_D_sphere', 'lLOC_E_sphere', 
                  'rLOC_A_sphere', 'rLOC_B_sphere',
                  'lSPC_A_sphere', 'lSPC_B_sphere', 'lSPC_C_sphere', 'lSPC_D_sphere', 'lSPC_E_sphere',
                  'rSPC_A_sphere', 'rSPC_B_sphere',
                  'lPCG_A_sphere',
                  'rPCG_A_sphere', 'rPCG_B_sphere', 'rPCG_C_sphere', 'rPCG_D_sphere', 
                  'ACC_A_sphere', 
                  'PCC_A_sphere',
                  'rAI_A_sphere', 
                  'lMFG_A_sphere', 'lMFG_B_sphere',
                  'mPFC_A_sphere', 'mPFC_B_sphere', 'mPFC_C_sphere')
  
  look <- read.table(sprintf("C:/Users/jguas/Desktop/McReapp/lss_trials/DAN/%s_expanded_lookNeg_lss_DAN_ts.txt", subs[i]))
  names(look) <- c('lLOC_A_sphere', 'lLOC_B_sphere', 'lLOC_C_sphere', 'lLOC_D_sphere', 'lLOC_E_sphere', 
                   'rLOC_A_sphere', 'rLOC_B_sphere',
                   'lSPC_A_sphere', 'lSPC_B_sphere', 'lSPC_C_sphere', 'lSPC_D_sphere', 'lSPC_E_sphere',
                   'rSPC_A_sphere', 'rSPC_B_sphere',
                   'lPCG_A_sphere',
                   'rPCG_A_sphere', 'rPCG_B_sphere', 'rPCG_C_sphere', 'rPCG_D_sphere', 
                   'ACC_A_sphere', 
                   'PCC_A_sphere',
                   'rAI_A_sphere', 
                   'lMFG_A_sphere', 'lMFG_B_sphere',
                   'mPFC_A_sphere', 'mPFC_B_sphere', 'mPFC_C_sphere')
  
  farSim = corr.test(far, method = "spearman")[[1]]
  lookSim = corr.test(look, method = "spearman")[[1]]
  
  farSimVec = farSim[lower.tri(farSim)]
  lookSimVec = lookSim[lower.tri(lookSim)]
  
  farSimVecZ = fisherz(farSimVec)
  lookSimVecZ = fisherz(lookSimVec)
  
  connectSim = cor(t(t(farSimVecZ)), t(t(lookSimVecZ)), method="spearman")
  
  outSim[i] = connectSim
  
  
  farSimZ = fisherz(farSim)
  farAdjm = farSimZ; farAdjm[ farSimZ == Inf] = 0; farAdjm[ farSimZ < .5000 ] = 0
  farGraph = graph_from_adjacency_matrix(farAdjm, mode = "undirected", weighted=TRUE)
  farMod = modularity(cluster_walktrap(farGraph))
  farComm = length(cluster_walktrap(farGraph))
  
  lookSimZ = fisherz(lookSim)
  lookAdjm = lookSimZ; lookAdjm[ lookSimZ == Inf] = 0; lookAdjm[ lookSimZ < .5000 ] = 0
  lookGraph = graph_from_adjacency_matrix(lookAdjm, mode = "undirected", weighted=TRUE)
  lookMod = modularity(cluster_walktrap(lookGraph))
  lookComm = length(cluster_walktrap(lookGraph))
  
  modDiff[i] = farMod - lookMod
  commDiff[i] = farComm - lookComm
}

behavDat = read_excel("C:/Users/jguas/Desktop/McReapp/behavData.xlsx")
behavDat$sim = outSim - mean(outSim)
behavDat$Capacity = behavDat$Capacity - mean(behavDat$Capacity)
behavDat$modDiff = modDiff - mean(modDiff)
behavDat$commDiff = commDiff - mean(commDiff)

m1 = lm(behavDat$Capacity ~ behavDat$sim)
m2 = lm(behavDat$Capacity ~ behavDat$sim + behavDat$cAge)
m3 = lm(behavDat$Capacity ~ behavDat$sim*behavDat$cAge)
