from numpy import loadtxt
import os

lines = loadtxt("cluster_info_VAN.txt", comments="#", delimiter="\t", unpack=False)
labs = ["rLOC_A", "lFFG_A", "lFFG_B", "rOP_A", "lIFG_A", "lLOC_A", "rFFG_A", "lLOC_B", "lAI_A", "rFFG_B", "lFFG_C",
        "lOP_A", "rFFG_C", "rFFG_D", "rLOC_B", "ACC_A", "rAI_A", "lLOC_C", "rFFG_E", "lLOC_D", "rLOC_C"]

for ln in range(0,len(lines)):
    x = lines[ln][3]
    y = lines[ln][4]
    z = lines[ln][5]
    os.system('fslmaths cluster_index_van.nii.gz -mul 0 -add 1 -roi %s 1 %s 1 %s 1 0 1 %spoint -odt float'%(x, y, z, labs[ln]))
    os.system('fslmaths %spoint.nii.gz -kernel sphere 4 -fmean %s_sphere -odt float'%(labs[ln], labs[ln]))
    print labs[ln]

os.system('rm *point*')

    
    
