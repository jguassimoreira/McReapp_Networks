from numpy import loadtxt
import os

lines = loadtxt("cluster_info_FPN.txt", comments="#", delimiter="\t", unpack=False)
labs = ["ACC_A", "rSPC_A", "lSPC_A", "rPMC_A", "lAI_A", "ldlPFC_A", "lPMC_A", "lSPC_B", "rAI_A", "rSPC_B", "Tha_A", "rdlPFC_A",
        "rSPC_C", "rSPC_D", "rdlPFC_B", "ACC_B", "ACC_C", "rSPC_E", "rSPC_F", "lSPC_C", "rSPC_G", "Tha_B", "rSPC_H",
        "rdlPFC_C", "ldlPFC_B"]

for ln in range(0,len(lines)):
    x = lines[ln][3]
    y = lines[ln][4]
    z = lines[ln][5]
    os.system('fslmaths cluster_index_fpn.nii.gz -mul 0 -add 1 -roi %s 1 %s 1 %s 1 0 1 %spoint -odt float'%(x, y, z, labs[ln]))
    os.system('fslmaths %spoint.nii.gz -kernel sphere 4 -fmean %s_sphere -odt float'%(labs[ln], labs[ln]))
    print labs[ln]

os.system('rm *point*')

    
    
